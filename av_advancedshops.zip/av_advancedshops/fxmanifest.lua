fx_version 'cerulean'
game 'gta5'

author '!AV Development'
description 'Advanced Shops for FiveM - ESX'
version '1.0.0'

shared_scripts {
    '@ox_lib/init.lua',
    'config/config.lua'
}

client_scripts {
    'client/client.lua'
}

server_scripts {
    '@mysql-async/lib/MySQL.lua',
    'server/server.lua'
}

files {
    'html/ui.html',
    'html/img/*.png'
}

ui_page 'html/ui.html' -- Přidání NUI pro načítání obrázků

lua54 'yes'