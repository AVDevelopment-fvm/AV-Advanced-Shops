Config = {}

Config.Locales = "en" -- "en" or "cs"

Config.Shops = {
    {
        name = "24/7 Supermarket",
        coords = vector4(25.7, -1347.3, 29.5, 270.0),
        items = {
            {label = "Burger", item = "burger", icon = "burger.png", price = 3},
            {label = "Water", item = "water", icon = "water.png", price = 2},
            {label = "Phone", item = "phone", icon = "phone.png", price = 50},
            {label = "Radio", item = "radio", icon = "radio.png", price = 25}
        },
        npcModel = "mp_m_shopkeep_01"
    }
}

Config.Translations = {
    en = {
        shop_menu = "Open Shop",
        purchase_quantity = "Enter quantity",
        enter_quantity = "How many would you like to buy?",
        payment_choice = "Choose payment method",
        choose_payment_method = "Type 'cash' for cash or 'bank' for bank transfer",
        not_enough_money = "You don't have enough money!",
        not_enough_bank_money = "You don't have enough money in your bank account!",
        invalid_payment_method = "Invalid payment method selected!",
        purchase_successful = "You bought %s for $%s!"
    },
    cs = {
        shop_menu = "Otevřít Obchod",
        purchase_quantity = "Zadejte množství",
        enter_quantity = "Kolik kusů chcete koupit?",
        payment_choice = "Vyberte způsob platby",
        choose_payment_method = "Zadejte 'cash' pro hotovost nebo 'bank' pro bankovní převod",
        not_enough_money = "Nemáte dostatek peněz!",
        not_enough_bank_money = "Nemáte dostatek peněz na bankovním účtu!",
        invalid_payment_method = "Byla vybrána neplatná metoda platby!",
        purchase_successful = "Koupili jste %s za $%s!"
    }
}