ESX = exports['es_extended']:getSharedObject()

local Lang = Config.Translations[Config.Locales] -- Loads the language from config.lua

-- Event for purchasing goods
RegisterNetEvent('av_advancedshops:buyItem', function(item, quantity, paymentMethod)
    local src = source
    local xPlayer = ESX.GetPlayerFromId(src) -- This method must be called on the server

    -- Check if the player exists
    if not xPlayer then return end

    local totalPrice = item.price * quantity -- Total price for all units

    -- Data validation
    if not item or not quantity or quantity <= 0 then
        return
    end

    -- Payment method validation
    if paymentMethod == 'cash' then
        if xPlayer.getMoney() >= totalPrice then
            -- Deduct money
            xPlayer.removeMoney(totalPrice)
            -- Add items to the inventory
            xPlayer.addInventoryItem(item.item, quantity)
            TriggerClientEvent('esx:showNotification', src, string.format(Lang.purchase_successful, item.label, totalPrice))
        else
            TriggerClientEvent('esx:showNotification', src, Lang.not_enough_money)
        end
    elseif paymentMethod == 'bank' then
        if xPlayer.getAccount('bank').money >= totalPrice then
            -- Deduct money from bank account
            xPlayer.removeAccountMoney('bank', totalPrice)
            -- Add items to the inventory
            xPlayer.addInventoryItem(item.item, quantity)
            TriggerClientEvent('esx:showNotification', src, string.format(Lang.purchase_successful, item.label, totalPrice))
        else
            TriggerClientEvent('esx:showNotification', src, Lang.not_enough_bank_money)
        end
    else
        TriggerClientEvent('esx:showNotification', src, Lang.invalid_payment_method)
    end
end)