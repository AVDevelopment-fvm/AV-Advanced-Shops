ESX = exports['es_extended']:getSharedObject()

local Lang = Config.Translations[Config.Locales] -- Loads the language from config.lua

Citizen.CreateThread(function()
    for _, shop in pairs(Config.Shops) do
        RequestModel(GetHashKey(shop.npcModel))
        while not HasModelLoaded(GetHashKey(shop.npcModel)) do
            Wait(1)
        end
        
        -- Create NPC for the shop
        local npc = CreatePed(4, GetHashKey(shop.npcModel), shop.coords.x, shop.coords.y, shop.coords.z - 1.0, shop.coords.w, false, true)
        SetEntityHeading(npc, shop.coords.w)
        FreezeEntityPosition(npc, true)
        SetEntityInvincible(npc, true)
        SetBlockingOfNonTemporaryEvents(npc, true)
        
        -- Add the shop NPC to the target system (ox_target)
        exports.ox_target:addLocalEntity(npc, {
            {
                name = 'av_advancedshops_shop_' .. shop.name,
                event = 'av_advancedshops:openMenu',
                icon = 'fas fa-shopping-cart',
                label = Lang.shop_menu,  -- Title of the menu
                distance = 2.5,
                shopData = shop
            }
        })
    end
end)

-- Event that opens the shop menu
RegisterNetEvent('av_advancedshops:openMenu', function(data)
    local shopData = data.shopData
    local options = {}

    -- Loop through each item in the shop and add it to the menu options
    for _, item in pairs(shopData.items) do
        table.insert(options, {
            title = item.label,
            description = "Price: $" .. item.price,
            icon = 'nui://av_advancedshops/html/img/' .. item.icon,  -- Path to the item's icon image
            onSelect = function()
                TriggerEvent('av_advancedshops:buyItem', item)  -- Trigger the buy item event when the player selects an item
            end
        })
    end

    -- Register the menu context and show it to the player
    lib.registerContext({
        id = 'av_advancedshops_shop_menu',
        title = shopData.name,
        options = options
    })

    lib.showContext('av_advancedshops_shop_menu')  -- Show the shop menu to the player
end)

-- Event for handling the purchase of an item
RegisterNetEvent('av_advancedshops:buyItem', function(item)
    -- Ask the player for the quantity they want to buy
    local input = lib.inputDialog(Lang.purchase_quantity, {Lang.enter_quantity})
    if not input then return end

    local quantity = tonumber(input[1])
    if not quantity or quantity <= 0 then
        return
    end

    -- Ask the player how they want to pay (cash or bank)
    local paymentChoice = lib.inputDialog(Lang.payment_choice, {Lang.choose_payment_method})
    if not paymentChoice then return end

    local paymentMethod = paymentChoice[1]
    if paymentMethod ~= 'cash' and paymentMethod ~= 'bank' then
        return
    end

    -- Send the request to the server to process the purchase
    TriggerServerEvent('av_advancedshops:buyItem', item, quantity, paymentMethod)
end)